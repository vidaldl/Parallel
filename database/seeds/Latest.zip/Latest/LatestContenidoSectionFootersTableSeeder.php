<?php

use Illuminate\Database\Seeder;

class LatestContenidoSectionFootersTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('contenido_section_footers')->delete();
        
        \DB::table('contenido_section_footers')->insert(array (
            0 => 
            array (
                'id' => '1',
                'copy' => 'Caribbean Equipment Medical',
                'logo' => 'content/footer/zutmt7SVUPL6YF7kKwBrGxeoPO64nWJWIICr3S2h.png',
                'social_title' => 'Conéctate',
                'acerca' => 'irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
                'style' => '2',
                'line' => '2',
                'line_style' => '1',
            ),
        ));
        
        
    }
}